from kyt import *

@bot.on(events.CallbackQuery(data=b'create-ssh2'))
async def create_ssh2(event):
	async def create_ssh2_(event):
		async with bot.conversation(chat) as user:
		    pw2 = "2"
			await event.edit(f"""
**✨ 𝙽𝚊𝚖𝚊 𝚋𝚎𝚛𝚞𝚙𝚊 𝚌𝚊𝚖𝚙𝚞𝚛𝚊𝚗, 
 𝙷𝚞𝚛𝚞𝚏 𝚔𝚊𝚙𝚒𝚝𝚊𝚕, 𝚍𝚊𝚗 𝙰𝚗𝚐𝚔𝚊**
**✨ No Space**
**✨ No double Name**
**✨ Bot : @abecasdee**

**✨ KETIK NAMA AKUN  :**
/cancel Kembali KeMENU
""")
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		per = "/cancel"
		if user == per:
			await event.respond(f"""
**» CANCEL**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
		else:
			async with bot.conversation(chat) as pw:
				await event.respond(f"""
**✨ KETIK PASWORD AKUN :**
""")
				pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				pw = (await pw).raw_text
			async with bot.conversation(chat) as exp:
				await event.edit("**Choose Expiry Day**",buttons=[
[Button.inline(" 3 Day ","3"),
Button.inline(" 7 Day ","7")],
[Button.inline(" 30 Day ","30"),
Button.inline(" 60 Day ","60")]])
				exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
				exp = (await exp).raw_text
			async with bot.conversation(chat) as pw2:
			cmd = f'printf "%s\n" "1" "{user}" "{pw}" "{exp}" "{pw2}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_ssh2_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)

@bot.on(events.CallbackQuery(data=b'trial-ssh2'))
async def trial_ssh2(event):
	async def trial_ssh2_(event):
	        exp = "60"
	        pw2 = "2"
			cmd = f'printf "%s\n" {2} "{exp}" | m-sshovpn | sleep 2 | exit'
			subprocess.check_output(cmd, shell=True)
			await event.respond(f"""
**» SUCCES CREATE**
**» DONE**
""",buttons=[[Button.inline("‹ Main Menu ›","menu")]])
	chat = event.chat_id
	sender = await event.get_sender()
	
@bot.on(events.CallbackQuery(data=b'ssh2'))
async def ssh2(event):
	async def ssh2_(event):
		inline = [
[Button.inline(" CREATE SSH ","create-ssh2"),
Button.inline(" TRIAL 1 JAM ","trial-ssh2"),
Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		sh = f' cat /etc/xray/ssh2 | grep "###" | wc -l'
		ssh2 = subprocess.check_output(sh, shell=True).decode("ascii")
		msg = f"""
◇━━━━━━━━━━━━━━━━━◇
      **💥⟨ _SF Panel Premium_ ⟩💥**
◇━━━━━━━━━━━━━━━━━◇
**» Hallo Boss**

**» User ID :**
**» Email :** `jhon1@satanfusion.id
**» Username :** @jhon1
**» Saldo :** `Null`
◇━━━━━━━━━━━━━━━━━◇
 Note : 
 _- Jika Bot Error, Coba Kirim Perintah /start_
 _- Top Up Otomatis Via TriPay_
 
 
**»🤖@abecasdee**
◇━━━━━━━━━━━━━━━━━◇
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	