from sf import *

@bot.on(events.CallbackQuery(data=b'ssh'))
async def ssh(event):
	async def ssh_(event):
		inline = [
[Button.inline(" ID ATHA ","ssh1"),
Button.inline(" SG DO ","ssh2")],
[Button.inline("‹ BACK ›","menu")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
	
		msg = f"""
◇━━━━━━━━━━━━━━━━━◇
      **💥⟨ _SF Panel Premium_ ⟩💥**
◇━━━━━━━━━━━━━━━━━◇
**» Hallo Boss**

**» User ID :**
**» Email :** `jhon1@satanfusion.id
**» Username :** @jhon1
**» Saldo :** `Null`
◇━━━━━━━━━━━━━━━━━◇
 Note : 
 _- Jika Bot Error, Coba Kirim Perintah /start_
 _- Top Up Otomatis Via TriPay_
 
 
**»🤖@abecasdee**
◇━━━━━━━━━━━━━━━━━◇
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()