from kyt import *

@bot.on(events.CallbackQuery(data=b'trojango'))
async def trgo(event):
	async def trgo_(event):
		inline = [
[Button.inline(" CREATE NOOBZ ","create-ssh"),
Button.inline(" SHOW USER ","cek-ssh")],
[Button.inline(" DELETE USER ","delete-ssh"),
Button.inline(" UNLOCK USER ","login-ssh")],
[Button.inline(" LOCK USER ","renew-ssh"),
Button.inline(" REMOVE ALL USER ","akun-ssh")],
[Button.inline(" RENEW NOOBZ ","renew-ssh"),
Button.inline("‹ BACK ›","manager")]]
		z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
		noob = f' cat /etc/xray/noob | grep "###" | wc -l'
		noobz = subprocess.check_output(noob, shell=True).decode("ascii")
		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**🔥 PANEL MENU SSH 🔥**
━━━━━━━━━━━━━━━━━━━━━━━ 
✨ **» Service:** `NOOBZVPNS`
✨ **» Total Account  :** `{noobz.strip()}` __account__
✨ **» Host:** `{DOMAIN}`
✨ **» ISP:** `{z["isp"]}`
✨ **» Country:** `{z["country"]}`
🤖 **» @abecasdee**
━━━━━━━━━━━━━━━━━━━━━━━ 
"""
		await event.edit(msg,buttons=inline)
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await trgo_(event)
	else:
		await event.answer("Access Denied",alert=True)