from kyt import *
import subprocess
import datetime as DT

@bot.on(events.NewMessage(pattern=r"(?:/registrasi)$"))
@bot.on(events.CallbackQuery(data=b'registrasi'))
async def registrasi_handler(event):
    chat = event.chat_id
    sender = await event.get_sender()
    user_id = str(event.sender_id)

  
        
    register_user(user_id)

    today = DT.date.today()
    later = today + DT.timedelta(days=int(0))
    msg = f"""
**━━━━━━━━━━━━━━━━**
**⟨ Registration Success ⟩**
**━━━━━━━━━━━━━━━━**
**» Your ID:** `{user_id}`
**» Username:** `{user}`
**» Balance:** `IDR.0`
**» Ketik /menu untuk login**
**━━━━━━━━━━━━━━━━**
**» 🛂@abecasdee13**
**━━━━━━━━━━━━━━━━**
"""
    
    await event.respond(msg)

