from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.start|/start)$"))
@bot.on(events.CallbackQuery(data=b'start'))
async def start(event):
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply(f"""```
◇━━━━━━━━━━━━━━━━━━━━━━━━━◇
         Acces Denied!!!
      Your ID : {sender.id}
◇━━━━━━━━━━━━━━━━━━━━━━━━━◇
```""")
	elif val == "true":

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━
**» Your ID :** `{sender.id}`
**» Username :** @{sender.username}
**» Email :** `{sender.username}@sfvpn.net`
━━━━━━━━━━━━━━━━━━━━━━━
**» Menu [ /menu ]**
🤖 **» @abecasdee**
👥 **» Member :** [ `{get_user_count()}` ]
━━━━━━━━━━━━━━━━━━━━━━━
"""
		x = await event.edit(msg)
		if not x:
			await event.reply(msg)

@bot.on(events.NewMessage(pattern=r"(?:.menu|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline("PANEL CREATE ACCOUNT","manager")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
            
			await event.reply(f"""```
◇━━━━━━━━━━━━━━━━━━━━━━━━━◇
         Acces Denied!!!
      Your ID : {sender.id}
◇━━━━━━━━━━━━━━━━━━━━━━━━━◇
```""")
	elif val == "true":

		msg = f"""
**━━━━━━━━━━━━━━━━━━━━━━━**
**        __❰ MEMBER PANEL MENU ❱__ **
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Your ID :** `{sender.id}`
**» Username :** @{sender.username}
**» Email :** `{sender.username}@sfvpn.net`
**━━━━━━━━━━━━━━━━━━━━━━━**
**» Bot Uptime :** {uptime}
👥 **» Reseller :** [ `{get_user_count()}` ]
**━━━━━━━━━━━━━━━━━━━━━━━**
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)




