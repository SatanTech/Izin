from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.menuv2|/menuv2)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def menu(event):
	inline = [
[Button.inline(" SERVER IKD ","ikd"),
Button.inline(" SERVER DO ","do")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
	
	msg = f"""
	✧◇───────────────────◇✧ 
      **💥⟨ 𝘽𝙤𝙩 𝘼𝙙𝙢𝙞𝙣 𝙎𝙁 ⟩💥**
✧◇───────────────────◇✧ 
**TESSS**
**»🤖@abecasdee**
✧◇───────────────────◇✧ 
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)